﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ServerApp
{
    class Program
    {
        // Incoming data from the client.  
        public static string data = null;
        static void Main(string[] args)
        {
            try
            {
                //IPAddress ipAd = IPAddress.Parse("172.21.5.99");
                //// use local m/c IP address, and 
                //// use the same in the client

                ///* Initializes the Listener */
                //TcpListener myList = new TcpListener(ipAd, 8001);

                ///* Start Listeneting at the specified port */
                //myList.Start();

                //Console.WriteLine("The server is running at port 8001...");
                //Console.WriteLine("The local End point is  :" +
                //                  myList.LocalEndpoint);
                //Console.WriteLine("Waiting for a connection.....");

                //Socket s = myList.AcceptSocket();
                //Console.WriteLine("Connection accepted from " + s.RemoteEndPoint);

                //byte[] b = new byte[100];
                //int k = s.Receive(b);
                //Console.WriteLine("Recieved...");
                //for (int i = 0; i < k; i++)
                //    Console.Write(Convert.ToChar(b[i]));

                //ASCIIEncoding asen = new ASCIIEncoding();
                //s.Send(asen.GetBytes("The string was recieved by the server."));
                //Console.WriteLine("\nSent Acknowledgement");
                ///* clean up */
                //s.Close();
                //myList.Stop();
                StartListening();
                //return null;

            }
            catch (Exception e)
            {
                Console.WriteLine("Error..... " + e.StackTrace);
            }

        }
    
        public static void StartListening()
        {
            // Data buffer for incoming data.  
            byte[] bytes = new Byte[1024];

            // Establish the local endpoint for the socket.  
            // Dns.GetHostName returns the name of the   
            // host running the application.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress ipAddress = ipHostInfo.AddressList[0];
            IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 11000);

            // Create a TCP/IP socket.  
            Socket listener = new Socket(ipAddress.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

            // Bind the socket to the local endpoint and   
            // listen for incoming connections.  

            Console.WriteLine("The server is running at port :" + localEndPoint.Port);
            Console.WriteLine("The local End point is  :" +
                             localEndPoint.Address);

            try
            {
                listener.Bind(localEndPoint);
                listener.Listen(10);

                // Start listening for connections.  
                while (true)
                {
                    Console.WriteLine("Waiting for a connection...");
                    // Program is suspended while waiting for an incoming connection.  
                    Socket handler = listener.Accept();
                    data = null;

                    // An incoming connection needs to be processed.  
                    while (true)
                    {
                        int bytesRec = handler.Receive(bytes);
                        data += Encoding.ASCII.GetString(bytes, 0, bytesRec);
                        //if (data.IndexOf("<EOF>") > -1)
                        //{
                        //    break;
                        //}
                        break;
                    }

                    // Show the data on the console.  
                    Console.WriteLine("Text received : {0}", data);

                    // Echo the data back to the client.  
                    byte[] msg = Encoding.ASCII.GetBytes(GetResponse());

                    handler.Send(msg);
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\nPress ENTER to continue...");
            Console.Read();

        }

        public static string GetResponse()
        {
            string XML = @"<?xml version='1.0'?> <CustSrchInqRs> <SEQUENCE>12345678</SEQUENCE> <ResponseData> <CUSTSRCH> <CUSTKEY>00000000082856</CUSTKEY> <NALINE1>MISS
                        Kathy Sue Smith Esq DVM</NALINE1> <NALINE2>1019 Black Willow Dr</NALINE2> <NALINE3></NALINE3> <NALINE4></NALINE4> <NALINE5></NALINE5>
                        <NALINE6></NALINE6> <FIRSTNAME>Kathy</FIRSTNAME> <MIDDLENAME>Sue</MIDDLENAME> <LASTNAME>Smith</LASTNAME> <NPERLINE1></NPERLINE1>
                        <NPERLINE2></NPERLINE2> <SHORTNAME>Smith, Kathy S</SHORTNAME> <TAXIDNBR>266-89-3456</TAXIDNBR> <TAXIDTYPE>S</TAXIDTYPE>
                        <AREACODE>0</AREACODE> <PHONENBR>0</PHONENBR> <DOB>19781121</DOB> <INSIDERCD></INSIDERCD> <VIPCODE>VIP</VIPCODE> </CUSTSRCH> <CUSTSRCH>
                        <CUSTKEY>00000000000558</CUSTKEY> <NALINE1>Kelly Smith</NALINE1> <NALINE2>388 E. MICHIGAN</NALINE2> <NALINE3>PO BOX1211</NALINE3>
                        <NALINE4>ORLANDO FL 32818</NALINE4> <NALINE5></NALINE5> <NALINE6></NALINE6> <FIRSTNAME>Kelly</FIRSTNAME> <MIDDLENAME></MIDDLENAME>
                        <LASTNAME>Smith</LASTNAME> <NPERLINE1></NPERLINE1> <NPERLINE2></NPERLINE2> <SHORTNAME>Smith, Kelly</SHORTNAME> <TAXIDNBR>888-55-
                        7777</TAXIDNBR> <TAXIDTYPE>S</TAXIDTYPE> <AREACODE>0</AREACODE> <PHONENBR>0</PHONENBR> <DOB>0</DOB> <INSIDERCD></INSIDERCD>
                        <VIPCODE></VIPCODE> </CUSTSRCH> <CUSTSRCH> <CUSTKEY>00000000001009</CUSTKEY> <NALINE1>MRS. KERRI A SMITH CPA</NALINE1> <NALINE2>P O BOX
                        1284</NALINE2> <NALINE3>FAIRFIELD BAY AR 72088</NALINE3> <NALINE4></NALINE4> <NALINE5></NALINE5> <NALINE6></NALINE6>
                        <FIRSTNAME>KERRI</FIRSTNAME> <MIDDLENAME>A</MIDDLENAME> <LASTNAME>SMITH</LASTNAME> <NPERLINE1></NPERLINE1> <NPERLINE2></NPERLINE2>
                        <SHORTNAME>SMITH, KERRI A</SHORTNAME> <TAXIDNBR>263-45-6789</TAXIDNBR> <TAXIDTYPE>S</TAXIDTYPE> <AREACODE>501</AREACODE> <PHONENBR>723-
                        4418</PHONENBR> <DOB>19760204</DOB> <INSIDERCD></INSIDERCD> <VIPCODE></VIPCODE> </CUSTSRCH>
                        1.	<RECS_RETURNED>0003</RECS_RETURNED><MOREDATA>N</MOREDATA></ResponseData> </CustSrchInqRs>";

            return XML;
        }

    }
}
